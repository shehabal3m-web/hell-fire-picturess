# Discord Image Guard Bot

A Discord bot that monitors all channels, deletes images sent by users,
re-sends them with a mention, and scans for security threats.

---

## Features

- Monitors **all channels** automatically
- Deletes the original image message
- Re-sends the image with a **@mention** of the sender
- Scans for **hidden malware** (EXE, PHP, ZIP inside images)
- Detects **PNG exploits** and Zip Bombs
- Blocks and warns if any threat is found

---

## Setup on Render (Free 24/7 Hosting)

### 1. Upload to GitHub
- Create a new repository on github.com
- Upload all files in this folder

### 2. Create a Render Account
- Go to render.com and sign up with GitHub

### 3. Create a Background Worker
- Click **New → Background Worker**
- Connect your GitHub repository
- Set the following:

| Setting | Value |
|---------|-------|
| Language | Python |
| Build Command | `pip install -r requirements.txt` |
| Start Command | `python main.py` |

### 4. Add Your Token
- Go to **Environment → Add Environment Variable**
- Key: `DISCORD_TOKEN`
- Value: your bot token

### 5. Deploy
- Click **Deploy** and your bot will run 24/7!

---

## Bot Permissions Required
- Read Messages
- Send Messages
- Manage Messages (to delete images)
- Attach Files

---

## Security Checks Performed

| Check | Description |
|-------|-------------|
| Fake Extension | Detects EXE/ZIP/PDF disguised as images |
| Hidden Code | Finds PHP/JS/HTML injected inside image data |
| PNG Chunk Analysis | Detects unknown or malicious PNG chunks |
| Zip Bomb Detection | Flags oversized chunks or files (+20MB) |
